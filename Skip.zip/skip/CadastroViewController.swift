//
//  ViewController.swift
//  cadastro
//
//  Created by Student on 02/12/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit



class CadastroViewController: UIViewController{
    
    
    @IBOutlet weak var nome: UITextField!
    
    
    @IBOutlet weak var email: UITextField!
    
    
    @IBAction func FazerCadastro(_ sender: Any) {
        nomeUsuario = nome.text!
        emailUsuario = email.text!
        if(nome.text != "" && email.text != "") {
            colocaCadastro()
        } else {
            let alert = UIAlertController(title: "Alerta", message: "Favor preencher ambos os campos.", preferredStyle: .alert)

            alert.addAction(UIAlertAction(title: "Entendi", style: .default))

            self.present(alert, animated: true, completion: nil)
        }
        
        performSegue(withIdentifier:"irParaQRCodeReader", sender: nil)
    }
    
    
    
    override func viewDidLoad() {
        let tap = UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing))
        view.addGestureRecognizer(tap)
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
}

