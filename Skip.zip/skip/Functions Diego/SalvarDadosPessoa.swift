//
//  SalvarDadosPessoa.swift
//  MeuInicio
//
//  Created by Student on 05/12/19.
//  Copyright © 2019 Student. All rights reserved.
//

import Foundation

// Mostrar todos arquivos do banco
// https://vocerateoured.mybluemix.net/Listar

// Colocar arquivo no banco
// https://vocerateoured.mybluemix.net/Postar

// Mudar arquivo do banco ("apagar cliente")
// https://vocerateoured.mybluemix.net/Mudar

// Deletar arquivo do banco
// https://vocerateoured.mybluemix.net/Deletar

//Funcao que coloca os dados do cadastro no banco de dados
func colocaNumero(){
    Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { timer in
        
        //Codigo para PUT, GET e POST https requests
        let parameters: [String: Any] = ["numero": String(numero)]
        //create the url with URL
        let url = URL(string: "https://diegobnodered.us-south.cf.appdomain.cloud/SalvarNumeroPessoasPost")! //change the url
        //create the session object
        let session = URLSession.shared
        //now create the URLRequest object using the url object
        var request = URLRequest(url: url)
        request.httpMethod = "POST" //set http method as POST
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) // pass dictionary to nsdata object and set it as request body
        } catch let error {
            print(error.localizedDescription)
        }
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        //create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
            guard error == nil else {
                return
            }
            guard let data = data else {
                return
            }
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] {
                    print(json)
                    // handle json...
                }
            } catch let error {
                print(error.localizedDescription)
            }
        })
        task.resume()
        
    }
    
}

