//
//  MostrarMesaViewController.swift
//  MeuInicio
//
//  Created by Student on 03/12/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit


class MostrarMesaViewController: UIViewController {
    
    @IBOutlet weak var numeroMesa: UILabel!
    
    //@IBAction func finalizar(_ sender: Any) {
        
    //}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        numeroMesa.text! = mesa
        // Do any additional setup after loading the view.
    }
    
    
}

