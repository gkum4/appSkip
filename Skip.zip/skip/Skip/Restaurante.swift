//
//  Restaurante.swift
//  Skip
//
//  Created by Gustavo Kumasawa on 03/12/19.
//  Copyright © 2019 Student. All rights reserved.
//

import Foundation

struct Restaurante: Codable { // or Decodable
    let _id: String
    let _rev: String
    let cod: String
    let nome: String
    let linkDaFila: String
}

var nomeDoRestaurante = ""
var linkDaFila = ""
var numeroDePessoasNaFila = 0
var tempoDeEspera = 0
