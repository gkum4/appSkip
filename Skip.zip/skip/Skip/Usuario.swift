//
//  Response.swift
//  Skip
//
//  Created by Student on 28/11/19.
//  Copyright © 2019 Student. All rights reserved.
//

import Foundation

struct Usuario: Codable { // or Decodable
    let _id: String
    let _rev: String
    let identificador: String
    let posiChegada: String
    let vezChegou: String
}

var minhaVezChegou = false
var meuIdentificador = 0
var minhaPosiChegada = 1
var meuId = ""
var meuRev = ""
var posiFila = 0
var usuarioNaFila = false
