import Foundation

// Mostrar todos arquivos do banco
// https://vocerateoured.mybluemix.net/Listar

// Colocar arquivo no banco
// https://vocerateoured.mybluemix.net/Postar

// Mudar arquivo do banco ("apagar cliente")
// https://vocerateoured.mybluemix.net/Mudar

// Deletar arquivo do banco
// https://vocerateoured.mybluemix.net/Deletar


//Funcao que cria identificador unico
func criarIdentificador(endereco: String) {
    let end: String = "\(endereco)listarDado"
    if let urll = URL(string: end) {
        URLSession.shared.dataTask(with: urll) { data, response, error in
            if let data = data {
                do {
                    let usuario = try JSONDecoder().decode([Usuario].self, from: data)
                    var existeIgual = true
                    while(existeIgual == true) {
                        meuIdentificador = Int.random(in: 1...1000)
                        existeIgual = false
                        for usu in usuario {
                            print(usu.identificador)
                            if(Int(usu.identificador) == meuIdentificador) {
                                
                                existeIgual = true
                            }
                        }
                    }
                } catch let error {
                    print(error)
                }
            }
        }.resume()
    }
}

func ultimaPosiFirst(endereco: String, handleComplete:(()->())){
    ultimaPosi(endereco: endereco)
    handleComplete() // call it when finished s.t what you want
}


//Funcao que coloca cliente na fila
func entrarNaFila(endereco: String) {
    if usuarioNaFila == true {
        print("cliente ja esta na fila")
        return
    }
    let end: String = "\(endereco)salvarDadoPost"
    ultimaPosi(endereco: linkDaFila)
    Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { timer in
        
        minhaPosiChegada = contUltimaPosi
        
        //Codigo para PUT, GET e POST https requests
        let parameters: [String: Any] = ["identificador": String(meuIdentificador), "posiChegada": String(minhaPosiChegada), "vezChegou": "nao"]
        //create the url with URL
        let url = URL(string: end)! //change the url
        //create the session object
        let session = URLSession.shared
        //now create the URLRequest object using the url object
        var request = URLRequest(url: url)
        request.httpMethod = "POST" //set http method as POST
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) // pass dictionary to nsdata object and set it as request body
        } catch let error {
            print(error.localizedDescription)
        }
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        //create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
            guard error == nil else {
                return
            }
            guard let data = data else {
                return
            }
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] {
                    print(json)
                    usuarioNaFila = true
                    // handle json...
                }
            } catch let error {
                print(error.localizedDescription)
            }
        })
        task.resume()
        
    }
    
}


//Funcao que tira cliente da fila
func sairDaFila(endereco: String) {
    if usuarioNaFila == false {
        print("cliente nao esta na fila")
        return
    }
    let end: String = "\(endereco)editaDado"
    pegaDemaisDados(endereco: linkDaFila)
    //pegarDemaisDadosFirst(endereco: linkDaFila) {() -> () in
    Timer.scheduledTimer(withTimeInterval: 5, repeats: false) { timer in
        //Codigo para PUT, GET e POST https requests
        let parameters: [String: Any] = ["_id": String(meuId), "_rev": String(meuRev), "identificador": "0", "posiChegada": "0", "vezChegou": "nao"]
        meuId = ""
        meuRev = ""
        minhaPosiChegada = 1
        posiFila = 0
        usuarioNaFila = false
        //create the url with URL
        let url = URL(string: end)! //change the url
        //create the session object
        let session = URLSession.shared
        //now create the URLRequest object using the url object
        var request = URLRequest(url: url)
        request.httpMethod = "PUT" //set http method as POST
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) // pass dictionary to nsdata object and set it as request body
        } catch let error {
            print(error.localizedDescription)
        }
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        //create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
            guard error == nil else {
                return
            }
            guard let data = data else {
                return
            }
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] {
                    print(json)
                    // handle json...
                }
            } catch let error {
                print(error.localizedDescription)
            }
        })
        task.resume()
    }
    
}

func pegarDemaisDadosFirst(endereco: String, handleComplete:(()->())){
    pegaDemaisDados(endereco: linkDaFila)
    handleComplete() // call it when finished s.t what you want
}


//Funcao que atualiza posicao do cliente na fila
func atualizarFila(endereco: String) {
    if usuarioNaFila == false {
        print("usuario nao esta na fila")
        return
    }
    let end: String = "\(endereco)listarDado"
    pegaDemaisDados(endereco: linkDaFila)
    //pegarDemaisDadosFirst(endereco: linkDaFila) {() -> () in
    Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { timer in
        if let url = URL(string: end) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let data = data {
                    do {
                        let usuarios = try JSONDecoder().decode([Usuario].self, from: data)
                        posiFila = 1
                        for usu in usuarios {
                            if minhaPosiChegada > Int(usu.posiChegada)! && Int(usu.posiChegada) != 0{
                                posiFila += 1
                            }
                            if usu.identificador == String(meuIdentificador) {
                                if usu.vezChegou == "sim" {
                                    minhaVezChegou = true
                                }
                            }
                            
                        }
                    } catch let error {
                        print(error)
                    }
                }
                }.resume()
        }
    }
    
}


//Funcao que verifica se cliente ja foi colocado na fila
func estaNaFila(endereco: String) -> Bool {
    var esta = false
    let end: String = "\(endereco)listarDado"
    if let url = URL(string: end) {
       URLSession.shared.dataTask(with: url) { data, response, error in
           if let data = data {
               do {
                let usuarios = try JSONDecoder().decode([Usuario].self, from: data)
                for usu in usuarios {
                    if(Int(usu.identificador) == meuIdentificador)
                    {
                        esta = true
                    }
                }
               } catch let error {
                   print(error)
                }
           }
       }.resume()
    }
    return esta
}
var contUltimaPosi = 1

//Funcao que colocar o valor da ultima posicao da fila na variavel contUltimaPosi
func ultimaPosi(endereco: String) {
    let end: String = "\(endereco)listarDado"
    if let url = URL(string: end) {
       URLSession.shared.dataTask(with: url) { data, response, error in
           if let data = data {
               do {
                let usuarios = try JSONDecoder().decode([Usuario].self, from: data)
                contUltimaPosi = 1
                for usu in usuarios {
                    if usu.posiChegada != "0" {
                        contUltimaPosi += 1
                    }
                }
               } catch let error {
                   print(error)
                }
           }
       }.resume()
    }
}


//Funcao que pega _id,_rev e posiChegada do banco de dados
func pegaDemaisDados(endereco: String) {
    let end: String = "\(endereco)listarDado"
    if let url = URL(string: end) {
       URLSession.shared.dataTask(with: url) { data, response, error in
           if let data = data {
               do {
                let usuarios = try JSONDecoder().decode([Usuario].self, from: data)
                for usu in usuarios {
                    if(Int(usu.identificador) == meuIdentificador)
                    {
                        meuId = usu._id
                        meuRev = usu._rev
                        minhaPosiChegada = Int(usu.posiChegada)!
                        if usu.vezChegou == "sim" {
                            minhaVezChegou = true
                        }
                    }
                }
               } catch let error {
                   print(error)
                }
           }
       }.resume()
    }
}




