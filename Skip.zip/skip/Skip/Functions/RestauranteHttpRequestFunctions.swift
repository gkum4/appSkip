//
//  RestauranteHttpRequestFunctions.swift
//  Skip
//
//  Created by Gustavo Kumasawa on 03/12/19.
//  Copyright © 2019 Student. All rights reserved.
//

import Foundation

//Funcao que pega os dados do restaurante
//get: nomeDoRestaurante, 
func getDadosDoRestaurante(codigo: String){
    if let url = URL(string: "https://giovaninodered.us-south.cf.appdomain.cloud/RestData/listarDado") {
       URLSession.shared.dataTask(with: url) { data, response, error in
           if let data = data {
               do {
                let restaurantes = try JSONDecoder().decode([Restaurante].self, from: data)
                for rest in restaurantes {
                    if(rest.cod == codigo)
                    {
                        linkDaFila = rest.linkDaFila
                        nomeDoRestaurante = rest.nome
                        print(nomeDoRestaurante)
                    }
                }
               } catch let error {
                   print(error)
                }
           }
       }.resume()
    }
}

