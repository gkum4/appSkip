//
//  ViewController.swift
//  Skip
//
//  Created by Student on 27/11/19.
//  Copyright © 2019 Student. All rights reserved.
//


import UIKit

class FilaViewController: UIViewController {
    
    @IBOutlet weak var displayNomeRestaurante: UILabel!
    
    @IBOutlet weak var displayTempo: UILabel!
    
    @IBOutlet weak var displayPosicao: UILabel!
    
    @IBOutlet weak var topobar: UIView!
    
    
    @IBAction func botaoCancelar(_ sender: Any) {
        sairDaFila(endereco: linkDaFila)
        linkDaFila = ""
        numeroDePessoasNaFila = 0
        tempoDeEspera = 0
        nomeDoRestaurante = ""
        meuIdentificador = 0
        minhaPosiChegada = 1
        meuId = ""
        meuRev = ""
        posiFila = 0
        usuarioNaFila = false
        minhaVezChegou = false
        performSegue(withIdentifier: "voltarParaQRScanner", sender: nil)
        
    }
    
    @IBAction func botaoSync(_ sender: Any) {
        if usuarioNaFila == true {
            print("usuario esta na fila")
            atualizarFila(endereco: linkDaFila)
            Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { timer in
                self.displayTempo.text = "\(String(posiFila*15)) minutos"
                self.displayPosicao.text = String(posiFila)
                if minhaVezChegou == true {
                    sairDaFila(endereco: linkDaFila)
                    linkDaFila = ""
                    numeroDePessoasNaFila = 0
                    tempoDeEspera = 0
                    nomeDoRestaurante = ""
                    meuIdentificador = 0
                    minhaPosiChegada = 1
                    meuId = ""
                    meuRev = ""
                    posiFila = 0
                    usuarioNaFila = false
                    minhaVezChegou = false
                    self.performSegue(withIdentifier: "irParaMostrarQRCode", sender: nil)
                }
            }
            //self.displayPosicao.text = String(posiFila)
        }
        else {
            print("usuario nao esta na fila")
            self.displayPosicao.text = "..."
        }
    }
    
    @IBAction func botaoEntrar(_ sender: Any) {
        entrarNaFila(endereco: linkDaFila)
        //entrarNaFilaFirst(endereco: linkDaFila) {() -> () in
        if usuarioNaFila == true {
            return
        }
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            if usuarioNaFila == true {
                self.displayPosicao.text = String(minhaPosiChegada)
                self.displayTempo.text = "\(String(minhaPosiChegada*15)) minutos"
                timer.invalidate()
            }
        }
    }
     
    @IBAction func botaoSair(_ sender: Any) {
        sairDaFila(endereco: linkDaFila)
       //sairDaFilaFirst(endereco: linkDaFila) {() -> () in
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            if posiFila == 0 {
                self.displayPosicao.text = "..."
                self.displayTempo.text = "..."
                timer.invalidate()
                
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.bringSubviewToFront(topobar)
        self.displayNomeRestaurante.text = nomeDoRestaurante
        criarIdentificador(endereco: linkDaFila)
        
        
        //criarIdentificador(endereco: linkDaFila)
        
        
        if posiFila == 0 {
            self.displayPosicao.text = "..."
            self.displayTempo.text = "..."
        }else {
            self.displayPosicao.text = String(posiFila)
            self.displayTempo.text = "\(String(posiFila*15)) minutos"
        }
        
        //Funcao que executa tarefa repetidamente em um intervalo de tempo
        Timer.scheduledTimer(withTimeInterval: 20, repeats: true) { timer in
            /*if randomNumber == 10 {
                timer.invalidate()
            }*///condicao de parada
            if usuarioNaFila == true {
                print("usuario esta na fila")
                atualizarFila(endereco: linkDaFila)
                Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                    if(posiFila != 0) {
                        self.displayPosicao.text = String(posiFila)
                        self.displayTempo.text = "\(String(posiFila*15)) minutos"
                        if minhaVezChegou == true {
                            sairDaFila(endereco: linkDaFila)
                            linkDaFila = ""
                            numeroDePessoasNaFila = 0
                            tempoDeEspera = 0
                            nomeDoRestaurante = ""
                            meuIdentificador = 0
                            minhaPosiChegada = 1
                            meuId = ""
                            meuRev = ""
                            posiFila = 0
                            usuarioNaFila = false
                            minhaVezChegou = false
                            self.performSegue(withIdentifier: "irParaMostrarQRCode", sender: nil)
                        }
                        timer.invalidate()
                    }
                }
                
            }
                
            else {
                print("usuario nao esta na fila")
                self.displayPosicao.text = "..."
                self.displayTempo.text = "..."
            }
            
        }
        
    }


}


