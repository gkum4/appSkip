//
//  ViewController.swift
//  cadastro
//
//  Created by Student on 02/12/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

var nomeUsuario = ""
var emailUsuario = ""
var senhaUsuario = ""

class CadastroViewController: UIViewController {
    
    
    @IBOutlet weak var nome: UITextField!
    
    
    @IBOutlet weak var email: UITextField!
    
    
    @IBOutlet weak var senha: UITextField!
    
    @IBAction func FazerCadastro(_ sender: Any) {
        nomeUsuario = nome.text!
        emailUsuario = email.text!
        senhaUsuario = senha.text!
        if(nome.text != "" && email.text != "") {
            colocaCadastro()
        } else {
            let alert = UIAlertController(title: "Alerta", message: "Campos não preenchidos", preferredStyle: .alert)

            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: nil))
            alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))

            self.present(alert, animated: true)
        }
        
        performSegue(withIdentifier:"mostraPessoas", sender: nil)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
}

