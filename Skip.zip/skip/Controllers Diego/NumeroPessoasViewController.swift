//
//  numeroPessoasViewController.swift
//  MeuInicio
//
//  Created by Student on 03/12/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

var numero = ""

class NumeroPessoasViewController: UIViewController {
    
    @IBOutlet weak var numeroPessoas: UITextField!
    
    @IBAction func proximaTela(_ sender: Any) {
        numero = numeroPessoas.text!
        performSegue(withIdentifier: "mostraQRCode", sender: nil)
        colocaNumero()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
}

