//
//  MostrarQRCodeViewController.swift
//  MeuInicio
//
//  Created by Student on 03/12/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit

var nmesa=0

class MostrarQRCodeViewController: UIViewController {
    
    
    @IBOutlet weak var ImagemQrcode: UIImageView!
    
    @IBAction func proximaTela(_ sender: Any) {
        nmesa = Int.random(in: 0 ..< 10)
        let xNSNumber = nmesa as NSNumber
        let numMesa = xNSNumber.stringValue
        mesa = numMesa
        performSegue(withIdentifier:"mostraMesa", sender: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var imagem = generateQRCode(from: "Restaurante")
        ImagemQrcode.image = imagem
        // Do any additional setup after loading the view.
    }
    
    
}


