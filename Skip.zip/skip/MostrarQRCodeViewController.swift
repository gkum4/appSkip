//
//  MostrarQRCodeViewController.swift
//  MeuInicio
//
//  Created by Student on 03/12/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit


class MostrarQRCodeViewController: UIViewController {
    
    
    @IBOutlet weak var ImagemQrcode: UIImageView!
    
    @IBAction func proximaTela(_ sender: Any) {
        nmesa = Int.random(in: 1 ..< 30)
        let xNSNumber = nmesa as NSNumber
        let numMesa = xNSNumber.stringValue
        mesa = numMesa
        performSegue(withIdentifier:"irParaMostrarMesa", sender: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let imagem = generateQRCode(from: "Minha identidade ainda nao foi revelada")
        ImagemQrcode.image = imagem
        // Do any additional setup after loading the view.
    }
    
    
}


