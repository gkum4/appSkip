//
//  numeroPessoasViewController.swift
//  MeuInicio
//
//  Created by Student on 03/12/19.
//  Copyright © 2019 Student. All rights reserved.
//

import UIKit


class NumeroPessoasViewController: UIViewController {
    
    @IBOutlet weak var numeroPessoas: UITextField!
    
    @IBOutlet weak var restNome: UILabel!
    
    @IBAction func proximaTela(_ sender: Any) {
        numero = numeroPessoas.text!
        
        colocaNumero()
        performSegue(withIdentifier: "irParaFila", sender: nil)
    }
    
    override func viewDidLoad() {
        
        Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { timer in
            if nomeDoRestaurante != "" {
                timer.invalidate()
            }
            self.restNome.text = nomeDoRestaurante
            criarIdentificador(endereco: linkDaFila)
        }
        
        let tap = UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing))
        view.addGestureRecognizer(tap)
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
}

